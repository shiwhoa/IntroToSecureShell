#!/bin/sh
make
yes 2 | ./Final_ChainParents
yes 4 | ./Final_ChainParents
yes 8 | ./Final_ChainParents
yes 2 | ./Final_ParentwithNchildren
yes 4 | ./Final_ParentwithNchildren
yes 8 | ./Final_ParentwithNchildren
