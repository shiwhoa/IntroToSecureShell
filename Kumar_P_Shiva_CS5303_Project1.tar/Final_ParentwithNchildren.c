#include <unistd.h>
#include <sys/types.h>
#include <stdio.h>
int main( )
{
pid_t child_pid; // Create Process ID type variable child_pid
int i;
int num;

printf("Enter number of Child Processes to be made by 1 single parent : \n");
scanf("%d",&num);

 for(i=0; i<num; i++)
 {
//printf("value of i before fork : %d \n", i);

child_pid = fork (); // Create a new instance of child process

//printf("value of i after fork : %d \n",i);

   if (child_pid < 0) 
   {
      printf("fork failed");
      return 1;
   }
   else if (child_pid == 0) 
   {
      printf ("\n Hello :) I am the Child Process %d !\n", i+1);
      printf ("\n My_PID = %d, My_Parent_PID = %d\n",getpid(), getppid( ) );
      break;
   } 
   else 
   {
      wait(NULL);
      //printf ("\n I am the Parent Process!\n");
      //printf ("\n My_PID = %d, My_Parent_PID = %d\n", getpid( ), getppid( ) );
   }
  }
    if (child_pid > 0)
   {
      printf ("\n I am the Parent Process running now after waiting! \n");
      printf ("\n My_PID = %d, My_Parent_PID = %d\n", getpid( ), getppid( ) );
   }
return 0;
}
