#include <unistd.h>
#include <sys/types.h>
#include <stdio.h>
int main( )
{
pid_t child_pid; // Create Process ID type variable child_pid
int i;
int num;

printf("Enter number of child processes to be created in chain(excluding First Parent process aka Child Process 0) : \n");
scanf("%d",&num);

printf ("\n I am the First Parent Process, (aka Child Process 0)! \n");
printf ("\n My_PID = %d, My_Parent_PID = %d\n", getpid( ), getppid( ) );

 for(i=0; i<num; i++)
 {
//printf("value of i before fork : %d \n", i);

child_pid = fork (); // Create a new instance of child process

//printf("value of i after fork : %d \n",i);

   if (child_pid < 0) 
   {
      printf("fork failed");
      return 1;
   }
   else if (child_pid == 0) 
   {
      printf ("\n Hello :) I am the Child Process %d, Child of Child Process %d !\n", i+1,i);
      printf ("\n My_PID = %d, My_Parent_PID = %d\n",getpid(), getppid( ) );
   } 
   else 
   {
      wait(NULL);
      printf ("\n Child process %d, now the parent, am continuing after waiting!\n",i);
      printf ("\n My_PID = %d, My_Parent_PID = %d\n", getpid( ), getppid( ) );
      break;
   }
  }
return 0;
}
